import logging
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
import requests

# Настройка логгера
logging.basicConfig(filename='server.log', level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s - %(message)s')


class RequestHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        request_body = json.loads(post_data.decode('utf-8'))

        if self.path == '/sendhttp':
            logging.info(f"Received POST request to /sendhttp with data: {request_body}")
            self.send_http_request(request_body)
        else:
            logging.warning(f"Received unknown POST request to {self.path}")
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b'Endpoint not found')

    def do_GET(self):
        if self.path == '/scan':
            logging.info(f"Received GET request to /scan")
            self.scan_network()
        else:
            logging.warning(f"Received unknown GET request to {self.path}")
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b'Endpoint not found')

    def send_http_request(self, request_body):
        target = request_body.get('Target')
        method = request_body.get('Method')
        headers = {request_body.get('Header'): request_body.get('Header-value')}

        try:
            logging.info(f"Sending HTTP {method} request to {target} with headers: {headers}")
            if method == "GET":
                response = requests.get(target, headers=headers)
            elif method == "POST":
                response = requests.post(target, headers=headers)

            response_body = {
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "content": response.text
            }
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(response_body).encode())
            logging.info(f"Received response: {response.status_code}, {response.headers}, {response.text}")
        except Exception as e:
            logging.error(f"Error occurred: {str(e)}")
            self.send_response(500)
            self.end_headers()
            self.wfile.write(str(e).encode())

    def scan_network(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        request_body = json.loads(post_data.decode('utf-8'))

        target = request_body.get('target')
        count = request_body.get('count')
        scanned_ips = []

        for i in range(1, count + 1):
            ip = f"{target}.{i}"
            response = os.popen(f'ping -n 1 {ip}').read()
            scanned_ips.append({ip: response})

        response_body = {
            "scanned_ips": scanned_ips
        }
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(response_body).encode())
        logging.info(f"Scanned network with target {target} and count {count}. Response: {response_body}")


def run(server_class=HTTPServer, handler_class=RequestHandler, port=3000):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f"Запуск сервера на порту {port}")
    logging.info(f"Server started on port {port}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    httpd.server_close()
    logging.info("Server stopped")


if __name__ == "__main__":
    run()


